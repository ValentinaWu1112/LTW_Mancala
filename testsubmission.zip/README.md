# LTW_Mancala

## Authors

Nome | Número de estudante
--- | ---:
[Pedro Pinheiro](https://sigarra.up.pt/feup/pt/FEST_GERAL.CURSOS_LIST?pv_num_unico=201906788)  | up201906788
[Rafael Camelo](https://sigarra.up.pt/feup/pt/FEST_GERAL.CURSOS_LIST?pv_num_unico=201907729) | up201907729